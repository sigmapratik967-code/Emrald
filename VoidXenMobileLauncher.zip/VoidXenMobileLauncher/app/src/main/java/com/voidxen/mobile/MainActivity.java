package com.voidxen.mobile;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final int PURPLE=Color.rgb(181,77,255), DARK=Color.rgb(18,10,29), WHITE=Color.WHITE;
    private FrameLayout root; private LinearLayout content; private JSONObject config=new JSONObject();
    private String configUrl=""; private String gamePackage=""; private JSONArray servers=new JSONArray();
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private TextView status;

    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(17,8,28)); getWindow().setNavigationBarColor(Color.rgb(17,8,28));
        configUrl=getPreferences(0).getString("config_url",""); loadLocalConfig(); buildHome(); if(!configUrl.isEmpty()) fetchConfig(); }
    private void loadLocalConfig(){try{InputStream in=getAssets().open("servers.json"); config=new JSONObject(read(in)); applyConfig(config);}catch(Exception ignored){} }
    private String read(InputStream in)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] b=new byte[4096]; int n; while((n=in.read(b))>0)out.write(b,0,n); return out.toString("UTF-8");}
    private void applyConfig(JSONObject j){config=j; servers=j.optJSONArray("servers"); if(servers==null)servers=new JSONArray(); gamePackage=j.optString("game_package",""); String bg=j.optString("background_image_url",""); if(!bg.isEmpty())loadBackground(bg); }
    private void fetchConfig(){worker.execute(()->{try{String url=configUrl.trim(); if(url.contains("dropbox.com") && !url.contains("dl=1")) url=url.replaceAll("[?&]dl=0"," ").trim()+(url.contains("?")?"&":"?")+"dl=1";
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(10000); c.setRequestProperty("User-Agent","VoidXenMobile/1.0"); String body=read(c.getInputStream()); c.disconnect(); JSONObject j=new JSONObject(body);
        runOnUiThread(()->{applyConfig(j); buildHome(); toast("Server configuration updated");});
    }catch(Exception e){runOnUiThread(()->toast("Could not load remote config. Using saved servers."));}});}
    private void loadBackground(String url){worker.execute(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setConnectTimeout(8000); c.setReadTimeout(8000); Bitmap bm=BitmapFactory.decodeStream(c.getInputStream()); c.disconnect(); if(bm!=null)runOnUiThread(()->{if(root!=null){ImageView bg=(ImageView)root.getChildAt(0); bg.setImageBitmap(bm);}});}catch(Exception ignored){}});}
    private void buildBase(){root=new FrameLayout(this); ImageView bg=new ImageView(this); bg.setImageResource(com.voidxen.mobile.R.drawable.launcher_bg); bg.setScaleType(ImageView.ScaleType.CENTER_CROP); root.addView(bg,new FrameLayout.LayoutParams(-1,-1)); View shade=new View(this); shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xAA10071D,0x6610071D,0xEE10071D})); root.addView(shade,new FrameLayout.LayoutParams(-1,-1)); ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(1); content.setPadding(dp(22),dp(22),dp(22),dp(26)); scroll.addView(content); root.addView(scroll); setContentView(root); }
    private void buildHome(){buildBase(); TextView top=label("VOIDXEN MOBILE",22,true); top.setLetterSpacing(.12f); content.addView(top); TextView sub=label("ROLEPLAY • MOBILE",11,true); sub.setTextColor(0xFFD7B4FF); content.addView(sub); space(170);
        TextView title=label("VOIDXEN\nMOBILE",36,true); title.setGravity(Gravity.CENTER); title.setLetterSpacing(.08f); content.addView(title,new LinearLayout.LayoutParams(-1,-2)); TextView tagline=label("YOUR CITY. YOUR STORY.",12,true); tagline.setGravity(Gravity.CENTER); tagline.setTextColor(0xFFE2C7FF); content.addView(tagline); space(32);
        Button play=button("PLAY",PURPLE); content.addView(play,wide()); play.setOnClickListener(v->showServers()); space(10);
        Button store=button("STORE",0xFF30213E); content.addView(store,wide()); store.setOnClickListener(v->showInfo("STORE","The in-game store will be available when connected to the game service.")); space(18);
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); String[] names={"SETTINGS","SERVER RULES","CHARACTERS"}; for(String n:names){TextView t=label(n,10,true); t.setTextColor(0xFFE4C9FF); t.setPadding(dp(8),dp(14),dp(8),dp(14)); nav.addView(t,new LinearLayout.LayoutParams(0,-2,1)); t.setGravity(Gravity.CENTER); t.setOnClickListener(v->{if(n.equals("SETTINGS"))showSettings();else if(n.equals("SERVER RULES"))showRules();else showInfo("CHARACTER SELECTION","Character selection will be provided by the connected game client.");});} content.addView(nav); status=label("SERVER CONFIG: "+(configUrl.isEmpty()?"LOCAL":"REMOTE"),10,false); status.setGravity(Gravity.CENTER); status.setTextColor(0xFFCEB5DF); content.addView(status); }
    private void showServers(){new AlertDialog.Builder(this).setTitle("SELECT SERVER").setItems(serverNames(),(d,which)->{try{JSONObject s=servers.getJSONObject(which); String endpoint=s.optString("ip")+":"+s.optInt("port"); new AlertDialog.Builder(this).setTitle(s.optString("name","Server" )).setMessage("Server: "+endpoint+"\nStatus: "+s.optString("status","Unknown")).setPositiveButton("COPY IP:PORT",(x,y)->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Server address",endpoint));toast("IP:Port copied");}).setNegativeButton("OPEN GAME",(x,y)->launchGame(endpoint)).setNeutralButton("CANCEL",null).show();}catch(Exception e){toast("Invalid server entry");}}).setNegativeButton("CLOSE",null).show(); }
    private String[] serverNames(){String[] a=new String[servers.length()]; for(int i=0;i<a.length;i++){JSONObject s=servers.optJSONObject(i); a[i]=(s==null?"Server":s.optString("id","" )+"  •  "+s.optString("name","Server"))+"  ("+(s==null?"":s.optString("status","Unknown"))+")";} if(a.length==0)return new String[]{"No servers configured"}; return a;}
    private void launchGame(String endpoint){if(gamePackage.isEmpty()){((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Server address",endpoint));toast("Game package is not configured. IP:Port copied.");return;} try{Intent i=getPackageManager().getLaunchIntentForPackage(gamePackage); if(i==null){toast("Game app is not installed.");return;} i.putExtra("server_ip",endpoint.substring(0,endpoint.lastIndexOf(':'))); i.putExtra("server_port",endpoint.substring(endpoint.lastIndexOf(':')+1)); startActivity(i);}catch(Exception e){toast("Could not open game client.");}}
    private void showSettings(){final EditText input=new EditText(this); input.setSingleLine(true); input.setText(configUrl); input.setHint("https://.../servers.json or Dropbox link"); input.setTextColor(WHITE); input.setHintTextColor(0xFFBBAAC8); LinearLayout box=new LinearLayout(this); box.setPadding(dp(20),dp(8),dp(20),0); box.addView(input); new AlertDialog.Builder(this).setTitle("REMOTE SERVER CONFIG").setMessage("Paste a direct HTTPS link to your servers.json file. Dropbox shared links are supported.").setView(box).setPositiveButton("SAVE & LOAD",(d,w)->{configUrl=input.getText().toString().trim();getPreferences(0).edit().putString("config_url",configUrl).apply(); if(!configUrl.isEmpty())fetchConfig();else toast("Remote config disabled");}).setNeutralButton("USE LOCAL CONFIG",(d,w)->{configUrl="";getPreferences(0).edit().remove("config_url").apply();loadLocalConfig();buildHome();}).setNegativeButton("CANCEL",null).show(); }
    private void showRules(){String rules="1. Respect all players and staff.\n\n2. No cheating, exploiting, or third-party advantages.\n\n3. No harassment, hate speech, or threats.\n\n4. Follow roleplay rules and staff instructions.\n\n5. Do not share accounts or attempt to bypass security.\n\n6. Use the official support channel for reports."; new AlertDialog.Builder(this).setTitle("SERVER RULES").setMessage(rules).setPositiveButton("I UNDERSTAND",null).show();}
    private void showInfo(String title,String msg){new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK",null).show();}
    private TextView label(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(WHITE);t.setTextSize(size);if(bold)t.setTypeface(null,1);return t;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(WHITE);b.setTextSize(14);b.setLetterSpacing(.08f);b.setAllCaps(false);GradientDrawable gd=new GradientDrawable();gd.setColor(color);gd.setCornerRadius(dp(12));b.setBackground(gd);return b;}
    private LinearLayout.LayoutParams wide(){return new LinearLayout.LayoutParams(-1,dp(54));}
    private void space(int h){View v=new View(this);content.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){super.onDestroy();worker.shutdownNow();}
}
