# VoidXen Mobile Android Launcher

Android Studio / GitHub-ready starter project. Native Java Android app, no third-party libraries.

## Features included
- English UI with purple gaming theme
- Original generated coastal-city / speedboat background
- Home screen, Play/server selector, Store placeholder, Settings, Server Rules, Character Selection placeholder
- Local fallback server list
- Remote HTTPS JSON configuration (Dropbox shared links and normal website links)
- Copy IP:Port action
- Optional external game launch integration via `game_package` and intent extras

## Remote server configuration
Host `config/servers.json` on your website or Dropbox. For Dropbox, create a shared link; the app changes `dl=0` to `dl=1` or appends `dl=1`.

Example:
```json
{
  "app_name": "VoidXen Mobile",
  "game_package": "",
  "background_image_url": "",
  "servers": [
    {"id":"001","name":"VoidXen Roleplay 01","ip":"188.127.241.74","port":1618,"status":"Online"},
    {"id":"002","name":"VoidXen Roleplay 02","ip":"188.127.241.74","port":2541,"status":"Online"},
    {"id":"003","name":"VoidXen Roleplay 03","ip":"188.127.241.74","port":1724,"status":"Online"}
  ]
}
```

In the app open **Settings → Remote Server Config**, paste the direct HTTPS JSON URL, then Save & Load. Update the JSON online to change IP/Port without rebuilding the APK.

`background_image_url` can be set to a direct HTTPS image URL. Leave blank to use the bundled speedboat/city background.

## Build
1. Open this folder in Android Studio (or import the GitHub repository).
2. Use JDK 17 and Android SDK Platform 34.
3. Let Gradle sync, then Build > Build APK(s).

## Important integration limits
- This project is a launcher UI and remote server-config foundation, not the actual SA-MP/CRMP game client.
- The Open Game action only launches an installed client if you set its real Android package name in `game_package`. It sends `server_ip` and `server_port` intent extras; your game client must explicitly support those extras or a documented deep link. Otherwise it copies the endpoint.
- A compiled `classes4.dex` is not a remote configuration file. Keep the remote IP/Port in `servers.json`; the app downloads it at runtime. Do not replace or download DEX files from an untrusted URL.
- The supplied UI screens for Store and Character Selection are clearly marked placeholders until the real game APIs/client integration are supplied.

## Build APK using GitHub from a phone
1. Create a GitHub repository and upload the contents of this ZIP.
2. Push the files to the `main` branch.
3. Open the repository's **Actions** tab and run **Build VoidXen Mobile APK** (or wait for the push workflow).
4. Open the completed workflow run and download the `VoidXenMobile-debug-apk` artifact.
