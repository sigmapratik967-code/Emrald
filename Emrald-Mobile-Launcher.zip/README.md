# Emrald Mobile – Game Launcher (UI)

Flow: Loading -> Menu (Play / Store) -> Server -> Character -> Spawn Point.
App name: **Emrald Mobile**, package `com.emrald.mobile`, APK: `Emrald-Mobile-debug.apk`.

## GitHub se APK banane ke steps
1. GitHub pe naya repo banao.
2. Is zip ka saara content (hidden `.github` folder samet) repo me upload/push karo.
3. Repo -> **Actions** -> "Build Emrald Mobile APK" -> **Run workflow**.
4. 3-5 min baad run khol ke neeche **Artifacts -> Emrald-Mobile-APK** download karo, zip kholo, APK install karo.

## Android Studio se
Folder open karo -> Build -> Build APK(s).

## Customize
- Servers / characters / spawn data: `MainActivity.kt` ke top me (demo data).
- Real game start: spawn card ke click me (`buildSpawns`) apna game launch code lagao.
- Logo: `res/drawable/ic_logo.xml`, colors: `res/values/colors.xml`.

## Dropbox se servers / logo badalna
1. `servers.json` (example: `servers.example.json`) Dropbox me upload karo.
2. Dropbox me file -> Share -> Copy link.
3. App me upar right gear icon -> link paste -> Save.
4. JSON me `servers` list badlo, `title1`/`title2` (naam) aur `logo` (PNG ka Dropbox link) bhi de sakte ho.
App agli baar khulte hi naya data le leta hai (offline me last saved data dikhata hai).

## Player name
Pehli baar app khulne par nickname puchta hai (save ho jata hai). Menu me top-left naam pe tap karke badal sakte ho.
Server JSON me `array` format ([ {name, online, maxonline, ...} ]) bhi chalta hai; extra fields ignore hote hain.

## servers.json fields (real format)
online, maxonline, color (hex, 000000 = default), x2 ("true"/"false"), key, name, firstname, secondname, url, ip, port.
Server pe tap -> character -> spawn pe tap karne par selected server ka ip:port `launchGame()` me milta hai (MainActivity.kt).
Logo/title bhi badalna ho to array ko `{ "title1": "", "title2": "", "logo": "<png link>", "servers": [ ... ] }` me wrap karo.
