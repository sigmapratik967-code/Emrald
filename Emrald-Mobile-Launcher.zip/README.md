# Emrald Mobile – Game Launcher (UI)

Flow: Loading -> Menu (Play / Store) -> Server -> Character -> Spawn Point.
App name: **Emrald Mobile**, package `com.emrald.mobile`, APK: `Emrald-Mobile-debug.apk`.

## GitHub se APK banane ke steps
1. GitHub pe naya repo banao.
2. Is zip ka saara content (hidden `.github` folder samet) repo me upload/push karo.
3. Repo -> **Actions** -> "Build Emrald Mobile APK" -> **Run workflow**.
4. 3-5 min baad run khol ke neeche **Artifacts -> Emrald-Mobile-APK** download karo, zip kholo, APK install karo.

## Android Studio se
Folder open karo -> Build -> Build APK(s).

## Customize
- Servers / characters / spawn data: `MainActivity.kt` ke top me (demo data).
- Real game start: spawn card ke click me (`buildSpawns`) apna game launch code lagao.
- Logo: `res/drawable/ic_logo.xml`, colors: `res/values/colors.xml`.
