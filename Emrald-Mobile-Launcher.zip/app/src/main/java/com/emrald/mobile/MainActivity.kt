package com.emrald.mobile

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    // ---- Demo data: yahan apna real server / character data connect karo ----
    data class Server(val id: String, val lang: String, val online: Int, val chars: List<String>)
    data class Hero(val name: String, val level: Int, val money: Long)
    data class Spawn(val title: String, val locked: Boolean, val color: Int)

    private val servers = listOf(
        Server("001", "EN", 1000, listOf("Mitchel_Cartes", "Ankit_Kinger", "Ankit_Raxo")),
        Server("006", "EN", 845, listOf("Ankit_Inavio")),
        Server("004", "EN", 634, listOf("Ankit_Playz")),
        Server("003", "EN", 845, listOf("Ankit_Raxo")),
        Server("007", "PTBR", 845, listOf("Ankit_Singh")),
        Server("002", "EN", 762, listOf("Ankit_Raxo"))
    )
    private val heroes = listOf(
        Hero("Ankit_Kinger", 1, 26916),
        Hero("Mitchel_Cartes", 28, 688886),
        Hero("Ankit_Raxo", 1, 850)
    )
    private val spawns = listOf(
        Spawn("EXIT POINT", false, 0xFF2B3A55.toInt()),
        Spawn("RAILWAY STATION", false, 0xFF1E6FD9.toInt()),
        Spawn("APARTMENT", true, 0xFF3B3B4F.toInt()),
        Spawn("HOUSE", true, 0xFF3B3B4F.toInt()),
        Spawn("FAMILY", false, 0xFF1F7A3A.toInt()),
        Spawn("FACTION", false, 0xFFB03A48.toInt())
    )

    private val stack = ArrayDeque<Int>()
    private lateinit var screens: Map<Int, View>
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(R.layout.activity_main)

        screens = listOf(R.id.splash, R.id.menu, R.id.server, R.id.chars, R.id.spawn)
            .associateWith { findViewById<View>(it) }

        addHeader(R.id.server, "SERVER", "Server rules")
        addHeader(R.id.chars, "CHARACTER SELECTION", "Requests")
        addHeader(R.id.spawn, "SPAWN POINT", "Server rules")

        buildServers()
        buildHeroes()
        buildSpawns()

        findViewById<View>(R.id.btnPlay).setOnClickListener { show(R.id.server) }
        findViewById<View>(R.id.btnStore).setOnClickListener { toast("Store jaldi aa raha hai") }
        findViewById<View>(R.id.btnSettings).setOnClickListener { toast("Settings") }

        onBackPressedDispatcher.addCallback(this) { goBack() }

        show(R.id.splash, push = false)
        handler.postDelayed({ stack.clear(); show(R.id.menu) }, 2500)
    }

    // ---- Navigation ----
    private fun show(id: Int, push: Boolean = true) {
        val target = screens.getValue(id)
        screens.values.forEach { if (it !== target) it.visibility = View.GONE }
        target.alpha = 0f
        target.visibility = View.VISIBLE
        target.animate().alpha(1f).setDuration(250).start()
        if (push) stack.addLast(id)
    }

    private fun goBack() {
        if (stack.isEmpty()) return
        if (stack.size > 1) {
            stack.removeLast()
            show(stack.last(), push = false)
        } else finish()
    }

    // ---- Builders ----
    private fun addHeader(screenId: Int, title: String, action: String) {
        val parent = findViewById<LinearLayout>(screenId)
        val v = layoutInflater.inflate(R.layout.view_header, parent, false)
        v.findViewById<TextView>(R.id.hTitle).text = title
        v.findViewById<TextView>(R.id.hAction).text = action
        v.findViewById<View>(R.id.hBack).setOnClickListener { goBack() }
        parent.addView(v, 0)
    }

    private fun buildServers() {
        val grid = findViewById<GridLayout>(R.id.serverGrid)
        servers.forEach { s ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.card_bg)
                setPadding(dp(10), dp(8), dp(10), dp(8))
                layoutParams = GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)
                ).apply { width = 0; setMargins(dp(6), dp(6), dp(6), dp(6)) }
                setOnClickListener { show(R.id.chars) }
            }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            top.addView(tv("#${s.id}  ${s.lang}", 12f, Color.WHITE, true),
                LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(tv("●  ${s.online}/1000", 12f, 0xFF6BFF2B.toInt()))
            card.addView(top)

            val people = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
            for (i in 0 until 3) {
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
                val img = ImageView(this).apply {
                    setImageResource(R.drawable.ic_person)
                    alpha = if (i < s.chars.size) 0.9f else 0.25f
                    setColorFilter(if (i < s.chars.size) 0xFFB8F5DC.toInt() else 0xFF34D399.toInt())
                }
                col.addView(img, LinearLayout.LayoutParams(dp(44), dp(52)))
                col.addView(tv(s.chars.getOrNull(i) ?: "", 8f, 0xCCFFFFFF.toInt()))
                people.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            }
            card.addView(people)
            grid.addView(card)
        }
    }

    private fun buildHeroes() {
        val row = findViewById<LinearLayout>(R.id.charRow)
        heroes.forEach { h ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setOnClickListener { show(R.id.spawn) }
            }
            col.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_person)
                setColorFilter(0xFFB8F5DC.toInt())
            }, LinearLayout.LayoutParams(dp(110), dp(150)))
            col.addView(tv(h.name, 13f, Color.WHITE, true))
            col.addView(tv("Level: ${h.level}", 11f, 0xCCFFFFFF.toInt()))
            col.addView(tv("$ ${h.money}", 11f, 0xFFF5C92A.toInt()))
            row.addView(col, LinearLayout.LayoutParams(dp(170), -2))
        }
    }

    private fun buildSpawns() {
        val row = findViewById<LinearLayout>(R.id.spawnRow)
        spawns.forEach { sp ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(10), 0) }
            val card = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(sp.color)
                    alpha = if (sp.locked) 120 else 255
                }
                rotation = -4f
                setOnClickListener {
                    if (sp.locked) toast("Locked") else toast("Emrald Mobile: ${sp.title} se game start hoga")
                }
            }
            if (sp.locked) {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                box.addView(ImageView(this).apply { setImageResource(R.drawable.ic_lock) })
                box.addView(tv("0", 12f, Color.WHITE, true))
                card.addView(box, FrameLayout.LayoutParams(-1, -1))
            }
            col.addView(card, LinearLayout.LayoutParams(dp(105), dp(180)))
            col.addView(tv(sp.title, 10f, 0xCCFFFFFF.toInt()).apply { setPadding(0, dp(8), 0, 0) })
            row.addView(col)
        }
    }

    // ---- Helpers ----
    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
