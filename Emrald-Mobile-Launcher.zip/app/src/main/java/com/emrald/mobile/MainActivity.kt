package com.emrald.mobile

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    data class Server(
        val name: String, val first: String, val second: String,
        val online: Int, val max: Int, val color: Int?, val x2: Boolean,
        val key: String, val url: String, val ip: String, val port: String,
        val chars: List<String>
    )
    data class Spawn(val title: String, val locked: Boolean, val color: Int)

    // Offline default servers. Dropbox JSON mil jaye to ye replace ho jaate hain.
    private fun demo(n: String, on: Int) =
        Server(n, n, "", on, 1000, null, false, "", "", "", "", emptyList())

    private val defaultServers = listOf(demo("001", 20), demo("002", 20), demo("003", 20))
    private var servers: List<Server> = defaultServers
    private var selected: Server? = null
    private var player: String = ""

    private val spawns = listOf(
        Spawn("EXIT POINT", false, 0xFF2B3A55.toInt()),
        Spawn("RAILWAY STATION", false, 0xFF1E6FD9.toInt()),
        Spawn("APARTMENT", true, 0xFF3B3B4F.toInt()),
        Spawn("HOUSE", true, 0xFF3B3B4F.toInt()),
        Spawn("FAMILY", false, 0xFF1F7A3A.toInt()),
        Spawn("FACTION", false, 0xFFB03A48.toInt())
    )

    private val stack = ArrayDeque<Int>()
    private lateinit var screens: Map<Int, View>
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("emrald", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(R.layout.activity_main)

        player = prefs.getString("player", "") ?: ""

        screens = listOf(R.id.splash, R.id.menu, R.id.server, R.id.chars, R.id.spawn)
            .associateWith { findViewById<View>(it) }

        addHeader(R.id.server, "SERVER", "Server rules")
        addHeader(R.id.chars, "CHARACTER SELECTION", "Requests")
        addHeader(R.id.spawn, "SPAWN POINT", "Server rules")

        buildSpawns()
        loadCache()
        refreshPlayer()

        findViewById<View>(R.id.btnPlay).setOnClickListener { show(R.id.server) }
        findViewById<View>(R.id.btnStore).setOnClickListener { toast("Store jaldi aa raha hai") }
        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<View>(R.id.tvPlayer).setOnClickListener { askName(false) }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goBack() }
        })

        show(R.id.splash, push = false)
        handler.postDelayed({
            stack.clear()
            show(R.id.menu)
            if (player.isBlank()) askName(true)
        }, 2500)
        loadRemote(false)
    }

    // ---------------- Player name ----------------
    private fun refreshPlayer() {
        findViewById<TextView>(R.id.tvPlayer).text = if (player.isBlank()) "Nickname daalo" else player
        buildServers()
        buildHeroes()
    }

    private fun askName(force: Boolean) {
        val input = EditText(this).apply {
            hint = "Name_Surname"
            setText(player)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.LengthFilter(24))
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, FrameLayout.LayoutParams(-1, -2))
        }
        val builder = AlertDialog.Builder(this)
            .setTitle("Apna nickname")
            .setMessage("Game me jo name use karte ho wahi likho")
            .setView(box)
            .setCancelable(!force)
            .setPositiveButton("OK", null)
        if (!force) builder.setNegativeButton("Cancel", null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = input.text.toString().trim().replace(" ", "_")
                if (!Regex("[A-Za-z0-9_]{3,24}").matches(n)) {
                    toast("3 se 24 letters/numbers/_ hi chalega")
                } else {
                    player = n
                    prefs.edit().putString("player", n).apply()
                    refreshPlayer()
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    // ---------------- Dropbox / remote config ----------------
    private fun normalize(u: String): String {
        var s = u.trim()
        if (s.contains("dropbox.com")) {
            s = s.replace("dl=0", "dl=1")
            if (!s.contains("dl=1") && !s.contains("raw=1")) s += if (s.contains("?")) "&dl=1" else "?dl=1"
        }
        return s
    }

    private fun downloadBytes(u: String): ByteArray {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        c.instanceFollowRedirects = true
        try {
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    // Dono format chalte hain: [ {...}, {...} ]  ya  { "servers": [ ... ], "logo": "...", ... }
    private fun parse(text: String): Pair<JSONObject, JSONArray?> {
        val t = text.trim().removePrefix("\uFEFF")
        return if (t.startsWith("[")) {
            Pair(JSONObject(), JSONArray(t))
        } else {
            val o = JSONObject(t)
            Pair(o, o.optJSONArray("servers"))
        }
    }

    private fun loadRemote(showToast: Boolean) {
        val url = prefs.getString("url", "") ?: ""
        if (url.isBlank()) return
        Thread {
            try {
                val text = String(downloadBytes(normalize(url)))
                val (cfg, arr) = parse(text)
                prefs.edit().putString("cache", text).apply()

                var bmp: Bitmap? = null
                val logoUrl = cfg.optString("logo", "")
                if (logoUrl.isNotBlank()) {
                    try {
                        val bytes = downloadBytes(normalize(logoUrl))
                        bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) File(filesDir, "logo.bin").writeBytes(bytes)
                    } catch (_: Exception) { }
                }
                runOnUiThread {
                    applyConfig(cfg, arr, bmp)
                    if (showToast) toast("Update ho gaya: ${servers.size} servers")
                }
            } catch (e: Exception) {
                if (showToast) runOnUiThread { toast("Link se JSON nahi mila. Link check karo.") }
            }
        }.start()
    }

    private fun loadCache() {
        try {
            val cached = prefs.getString("cache", null) ?: return
            val f = File(filesDir, "logo.bin")
            val bmp = if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
            val (cfg, arr) = parse(cached)
            applyConfig(cfg, arr, bmp)
        } catch (_: Exception) { }
    }

    private fun applyConfig(cfg: JSONObject, arr: JSONArray?, logo: Bitmap?) {
        cfg.optString("title1", "").takeIf { it.isNotBlank() }?.let { findViewById<TextView>(R.id.title1).text = it }
        cfg.optString("title2", "").takeIf { it.isNotBlank() }?.let { findViewById<TextView>(R.id.title2).text = it }
        if (logo != null) findViewById<ImageView>(R.id.logoImg).setImageBitmap(logo)

        if (arr != null && arr.length() > 0) {
            servers = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val name = o.optString("name", "").ifBlank { "%03d".format(i + 1) }
                val ch = o.optJSONArray("chars")
                Server(
                    name = name,
                    first = o.optString("firstname", "").ifBlank { name },
                    second = o.optString("secondname", ""),
                    online = o.optString("online", "0").trim().toIntOrNull() ?: 0,
                    max = o.optString("maxonline", "1000").trim().toIntOrNull() ?: 1000,
                    color = parseColor(o.optString("color", "")),
                    x2 = o.optString("x2", "false").equals("true", ignoreCase = true),
                    key = o.optString("key", ""),
                    url = o.optString("url", ""),
                    ip = o.optString("ip", "").trim(),
                    port = o.optString("port", "").trim(),
                    chars = if (ch == null) emptyList() else (0 until ch.length()).map { ch.getString(it) }
                )
            }
            buildServers()
        }
    }

    private fun showSettings() {
        val input = EditText(this).apply {
            hint = "Dropbox link (servers.json)"
            setText(prefs.getString("url", ""))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, FrameLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(this)
            .setTitle("Server list link")
            .setMessage("Dropbox ka share link yahan paste karo")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("url", input.text.toString().trim()).apply()
                loadRemote(true)
            }
            .setNeutralButton("Reset") { _, _ ->
                prefs.edit().remove("url").remove("cache").apply()
                File(filesDir, "logo.bin").delete()
                servers = defaultServers
                buildServers()
                toast("Default servers wapas aa gaye")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------- Navigation ----------------
    private fun show(id: Int, push: Boolean = true) {
        val target = screens.getValue(id)
        screens.values.forEach { if (it !== target) it.visibility = View.GONE }
        target.alpha = 0f
        target.visibility = View.VISIBLE
        target.animate().alpha(1f).setDuration(250).start()
        if (push) stack.addLast(id)
    }

    private fun goBack() {
        if (stack.isEmpty()) return
        if (stack.size > 1) {
            stack.removeLast()
            show(stack.last(), push = false)
        } else finish()
    }

    // ---------------- Builders ----------------
    private fun addHeader(screenId: Int, title: String, action: String) {
        val parent = findViewById<LinearLayout>(screenId)
        val v = layoutInflater.inflate(R.layout.view_header, parent, false)
        v.findViewById<TextView>(R.id.hTitle).text = title
        v.findViewById<TextView>(R.id.hAction).text = action
        v.findViewById<View>(R.id.hBack).setOnClickListener { goBack() }
        parent.addView(v, 0)
    }

    private fun buildServers() {
        val grid = findViewById<GridLayout>(R.id.serverGrid)
        grid.removeAllViews()
        servers.forEach { s ->
            // Server ke chars JSON me na ho to player ka apna nickname dikhao
            val names = if (s.chars.isNotEmpty()) s.chars else listOf(player).filter { it.isNotBlank() }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = GradientDrawable().apply {
                    cornerRadius = dp(8).toFloat()
                    setColor(0x33FFFFFF)
                    setStroke(dp(if (s.color != null) 2 else 1), s.color ?: 0x2210B981)
                }
                setPadding(dp(10), dp(8), dp(10), dp(8))
                layoutParams = GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)
                ).apply { width = 0; setMargins(dp(6), dp(6), dp(6), dp(6)) }
                setOnClickListener { selected = s; show(R.id.chars) }
            }
            val label = "#${s.first}  ${s.second}".trim()
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            top.addView(tv(label, 12f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
            if (s.x2) top.addView(tv("x2   ", 11f, 0xFFF5C92A.toInt(), true))
            top.addView(tv("●  ${s.online}/${s.max}", 12f, 0xFF6BFF2B.toInt()))
            card.addView(top)

            val people = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
            for (i in 0 until 3) {
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
                val filled = i < names.size
                val img = ImageView(this).apply {
                    setImageResource(R.drawable.ic_person)
                    alpha = if (filled) 0.9f else 0.25f
                    setColorFilter(if (filled) 0xFFB8F5DC.toInt() else 0xFF34D399.toInt())
                }
                col.addView(img, LinearLayout.LayoutParams(dp(44), dp(52)))
                col.addView(tv(names.getOrNull(i) ?: "", 8f, 0xCCFFFFFF.toInt()))
                people.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            }
            card.addView(people)
            grid.addView(card)
        }
    }

    private fun buildHeroes() {
        val row = findViewById<LinearLayout>(R.id.charRow)
        row.removeAllViews()
        for (i in 0 until 3) {
            val filled = i == 0 && player.isNotBlank()
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                if (filled) setOnClickListener { show(R.id.spawn) }
            }
            col.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_person)
                setColorFilter(if (filled) 0xFFB8F5DC.toInt() else 0xFF34D399.toInt())
                alpha = if (filled) 1f else 0.25f
            }, LinearLayout.LayoutParams(dp(110), dp(150)))
            if (filled) {
                col.addView(tv(player, 13f, Color.WHITE, true))
                col.addView(tv("Level: 1", 11f, 0xCCFFFFFF.toInt()))
                col.addView(tv("$ 0", 11f, 0xFFF5C92A.toInt()))
            } else {
                col.addView(tv("Empty slot", 12f, 0x99FFFFFF.toInt()))
            }
            row.addView(col, LinearLayout.LayoutParams(dp(170), -2))
        }
    }

    private fun buildSpawns() {
        val row = findViewById<LinearLayout>(R.id.spawnRow)
        spawns.forEach { sp ->
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(10), 0) }
            val card = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(sp.color)
                    alpha = if (sp.locked) 120 else 255
                }
                rotation = -4f
                setOnClickListener {
                    if (sp.locked) toast("Locked") else launchGame(sp)
                }
            }
            if (sp.locked) {
                val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                box.addView(ImageView(this).apply { setImageResource(R.drawable.ic_lock) })
                box.addView(tv("0", 12f, Color.WHITE, true))
                card.addView(box, FrameLayout.LayoutParams(-1, -1))
            }
            col.addView(card, LinearLayout.LayoutParams(dp(105), dp(180)))
            col.addView(tv(sp.title, 10f, 0xCCFFFFFF.toInt()).apply { setPadding(0, dp(8), 0, 0) })
            row.addView(col)
        }
    }

    // Yahan apna game client launch karo. Abhi sirf selected server ka ip:port dikhata hai.
    private fun launchGame(sp: Spawn) {
        val s = selected
        if (s == null || s.ip.isBlank()) toast("Is server ka ip/port servers.json me daalo")
        else toast("${s.ip}:${s.port}  (${sp.title})")
    }

    private fun parseColor(raw: String): Int? {
        val t = raw.trim().removePrefix("#")
        if (t.length != 6 || t.all { it == '0' }) return null
        return try { Color.parseColor("#$t") } catch (_: Exception) { null }
    }

    // ---------------- Helpers ----------------
    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
