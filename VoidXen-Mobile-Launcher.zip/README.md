# VoidXen Mobile - Game Launcher

Flow: Splash -> Home (Play / News / Support / Settings) -> Server list -> Download / Update / Install / Play.

## 1. Build config (ek hi file): `launcher.properties`
appName, apkName, applicationId (package), versionName, versionCode, minSdk, buildType.
GitHub Actions APK ko `<apkName>.apk` naam se bahar nikalta hai.
Launcher icon: `app/src/main/res/drawable/ic_launcher_foreground.xml` + `values/colors.xml (ic_bg)`.

## 2. Runtime config (ek hi file): `app/src/main/assets/launcher_config.json`
Top level: supportUrl (Discord), rulesUrl, newsUrl (JSON array), profileApiUrl, remoteConfigUrl, news[], servers[].
Har server:
| field | kaam |
|---|---|
| name / firstname / secondname | card label (#001 + tag) |
| ip, port | server address (status query + game ko pass hota hai) |
| statusUrl | optional JSON API: players/online/count, maxplayers/maxonline/max, status |
| downloadUrl | Dropbox link (har server ka alag) |
| downloadFile | save hone wala naam (.apk ya .zip) |
| sha256 | file validation (khali = sirf size check) |
| version | badlo to launcher "Update" dikhata hai |
| gamePackage | game ka package name (launch ke liye) |
| color, x2 | card border colour, x2 tag |

Bina rebuild ke badalna: Dropbox pe config JSON rakho (object ya sirf servers ka array) ->
app me Settings -> "Server config link" me paste karo, ya `remoteConfigUrl` me daalo.

## 3. Live data (fake nahi)
- Player count: statusUrl API, ya (statusUrl khali ho) SA-MP UDP query ip:port par.
- Jab data na mile to "Status unavailable" / "Offline" dikhta hai, kabhi bana hua number nahi.
- Balance: profileApiUrl?nick=<name> se `{"balance": ...}`; na ho to "—".

## 4. Downloads
Resume (HTTP Range, .part file), progress, error messages, SHA-256 validation, Wi-Fi only option,
zip extract (zip-slip safe), APK install prompt. App foreground me rehni chahiye (screen on rakha jata hai);
beech me ruke to dobara dabane par resume hota hai.

## 5. Game ko kya milta hai
Launch intent extras: nickname, server_name, server_ip, server_port, graphics_quality, language, data_dir.
Aapke game client ko ye extras padhne honge.

## 6. DEX
Dekho `docs/DEX.md`.
