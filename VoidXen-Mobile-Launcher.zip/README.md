# VoidXen Mobile - Game Launcher

Flow: Splash -> Login -> Home (Play / News / Support / Settings) -> Server list -> **Connect screen** -> game.

### Login
- `authApiUrl` khali: offline profile (sirf nickname, koi password nahi; identity verify nahi hoti).
- `authApiUrl` (https) set: real Login/Register. Launcher POST karta hai:
  `{"action":"login"|"register","username":"..","password":".."}`
  Server jawab de: `{"ok":true,"token":"..","nickname":"..","balance":"123"}` ya `{"ok":false,"error":".."}`.
  Password kabhi save nahi hota; sirf token app-private storage me rehta hai. Game ko `auth_token` extra milta hai,
  isliye token ki asli verification aapke game server ko karni hogi.

### Connect screen (Play dabane par)
4 real steps: 1) player profile/login 2) game files (installed / download / update / install)
3) server address + live status 4) game launch. Koi step fail ho to saaf reason + Retry/Download/Update/Install/Login button.
Game files na hon to yahin "Cannot connect: Game files not found" dikhta hai. Server offline ho tab bhi game launch hota hai
(warning ke saath), aage ka connect game khud karta hai.

## 1. Build config (ek hi file): `launcher.properties`
appName, apkName, applicationId (package), versionName, versionCode, minSdk, buildType.
GitHub Actions APK ko `<apkName>.apk` naam se bahar nikalta hai.
Launcher icon: `app/src/main/res/drawable/ic_launcher_foreground.xml` + `values/colors.xml (ic_bg)`.

## 2. Runtime config (ek hi file): `app/src/main/assets/launcher_config.json`
Top level: supportUrl (Discord), rulesUrl, newsUrl (JSON array), profileApiUrl, authApiUrl, remoteConfigUrl, news[], servers[].
Har server:
| field | kaam |
|---|---|
| name / firstname / secondname | card label (#001 + tag) |
| ip, port | server address (status query + game ko pass hota hai) |
| statusUrl | optional JSON API: players/online/count, maxplayers/maxonline/max, status |
| downloadUrl | Dropbox link (har server ka alag) |
| downloadFile | save hone wala naam (.apk ya .zip) |
| sha256 | file validation (khali = sirf size check) |
| version | badlo to launcher "Update" dikhata hai |
| gamePackage | game ka package name (launch ke liye) |
| color, x2 | card border colour, x2 tag |

Bina rebuild ke badalna: Dropbox pe config JSON rakho (object ya sirf servers ka array) ->
app me Settings -> "Server config link" me paste karo, ya `remoteConfigUrl` me daalo.

## 3. Live data (fake nahi)
- Player count: statusUrl API, ya (statusUrl khali ho) SA-MP UDP query ip:port par.
- Jab data na mile to "Status unavailable" / "Offline" dikhta hai, kabhi bana hua number nahi.
- Balance: profileApiUrl?nick=<name> se `{"balance": ...}`; na ho to "—".

## 4. Downloads
Resume (HTTP Range, .part file), progress, error messages, SHA-256 validation, Wi-Fi only option,
zip extract (zip-slip safe), APK install prompt. App foreground me rehni chahiye (screen on rakha jata hai);
beech me ruke to dobara dabane par resume hota hai.

## 5. Game ko kya milta hai
Launch intent extras: nickname, server_name, server_ip, server_port, graphics_quality, language, data_dir.
Aapke game client ko ye extras padhne honge.

## 6. DEX
Dekho `docs/DEX.md`.
