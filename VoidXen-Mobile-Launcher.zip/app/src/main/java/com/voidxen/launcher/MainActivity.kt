package com.voidxen.launcher

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import androidx.core.os.LocaleListCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean

// Reference video se liye gaye colours
private val C_YELLOW = Color.parseColor("#F7CA2A")
private val C_PURPLE = Color.parseColor("#CA6FFD")
private val C_GREEN = Color.parseColor("#65EF00")
private val C_DIM = Color.parseColor("#B9ABD3")
private val C_RED = Color.parseColor("#FF6B6B")
private val C_CARD = Color.parseColor("#381A58")
private val C_STROKE = Color.parseColor("#4A2A75")
private val C_BTN_TEXT = Color.parseColor("#2D1457")

class MainActivity : AppCompatActivity() {

    private enum class St { DOWNLOAD, UPDATE, INSTALL, PLAY, NOCONFIG }

    private class CardHolder(
        val cfg: ServerCfg,
        val count: TextView,
        val progressRow: LinearLayout,
        val progress: ProgressBar,
        val pct: TextView,
        val button: TextView
    ) {
        fun setProgress(done: Long, total: Long) {
            if (total > 0) {
                progress.isIndeterminate = false
                progress.progress = (done * 100 / total).toInt()
                pct.text = "${done * 100 / total}%   ${mb(done)} / ${mb(total)} MB"
            } else {
                progress.isIndeterminate = true
                pct.text = "${mb(done)} MB"
            }
        }

        private fun mb(b: Long): String = "%.1f".format(b / 1048576.0)
    }

    private lateinit var cfg: AppConfig
    private val prefs by lazy { getSharedPreferences("voidxen", Context.MODE_PRIVATE) }
    private var player = ""
    private var balance = "—"
    private var newsList: List<NewsItem> = emptyList()

    private val stack = ArrayDeque<Int>()
    private lateinit var screens: Map<Int, View>
    private val handler = Handler(Looper.getMainLooper())
    private val holders = LinkedHashMap<String, CardHolder>()
    private val statuses = HashMap<String, Status?>()
    private val running = HashMap<String, AtomicBoolean>()
    private val balanceViews = ArrayList<TextView>()
    private val actionViews = ArrayList<TextView>()
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val pollTask = object : Runnable {
        override fun run() {
            refreshStatuses()
            fetchProfile()
            handler.postDelayed(this, 15000)
        }
    }

    // ------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(R.layout.activity_main)

        val base = ConfigLoader.fromAssets(this)
        cfg = try {
            prefs.getString("remote_cache", null)?.let { ConfigLoader.parse(it, base) } ?: base
        } catch (e: Exception) {
            base
        }
        player = prefs.getString("player", "") ?: ""
        newsList = cfg.news

        screens = listOf(R.id.splash, R.id.home, R.id.servers, R.id.settings)
            .associateWith { findViewById<View>(it) }

        addHeader(R.id.servers, R.string.servers_title, true)
        addHeader(R.id.settings, R.string.settings_title, false)
        wireHome()
        buildServers()
        refreshPlayer()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { goBack() }
        })

        show(R.id.splash, push = false)
        handler.postDelayed({
            stack.clear()
            show(R.id.home)
            if (player.isBlank()) askName(true)
        }, 1800)
        loadRemote(false)
    }

    override fun onResume() {
        super.onResume()
        holders.values.forEach { updateCard(it) }
        handler.removeCallbacks(pollTask)
        handler.post(pollTask)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(pollTask)
    }

    // ------------------------------------------------------------ home + header
    private fun wireHome() {
        registerBalance(findViewById(R.id.tvBalanceHome))
        findViewById<View>(R.id.btnPlay).setOnClickListener { show(R.id.servers) }
        findViewById<View>(R.id.btnNews).setOnClickListener { showNews() }
        findViewById<View>(R.id.btnSupport).setOnClickListener { openUrl(cfg.supportUrl) }
        findViewById<View>(R.id.btnSettings).setOnClickListener { buildSettings(); show(R.id.settings) }
        findViewById<View>(R.id.tvPlayer).setOnClickListener { askName(false) }
    }

    private fun registerBalance(tv: TextView) {
        tv.paintFlags = tv.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        tv.text = balance
        balanceViews.add(tv)
    }

    private fun addHeader(screenId: Int, @StringRes title: Int, showRules: Boolean) {
        val parent = findViewById<LinearLayout>(screenId)
        val v = layoutInflater.inflate(R.layout.view_header, parent, false)
        v.findViewById<TextView>(R.id.hTitle).setText(title)
        v.findViewById<View>(R.id.hBack).setOnClickListener { goBack() }
        v.findViewById<View>(R.id.hSupport).setOnClickListener { openUrl(cfg.supportUrl) }
        registerBalance(v.findViewById<TextView>(R.id.hBalance))
        val action = v.findViewById<TextView>(R.id.hAction)
        action.paintFlags = action.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        if (showRules) {
            actionViews.add(action)
            action.setOnClickListener { openUrl(cfg.rulesUrl) }
        }
        parent.addView(v, 0)
        updateHeaderActions()
    }

    private fun updateHeaderActions() {
        actionViews.forEach { it.visibility = if (cfg.rulesUrl.isNotBlank()) View.VISIBLE else View.GONE }
    }

    // ------------------------------------------------------------ player name
    private fun refreshPlayer() {
        findViewById<TextView>(R.id.tvPlayer).text = if (player.isBlank()) getString(R.string.nick_prompt) else player
    }

    private fun askName(force: Boolean) {
        val input = EditText(this).apply {
            hint = "Name_Surname"
            setText(player)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            filters = arrayOf(InputFilter.LengthFilter(24))
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, FrameLayout.LayoutParams(-1, -2))
        }
        val builder = AlertDialog.Builder(this)
            .setTitle(R.string.nick_title)
            .setMessage(R.string.nick_msg)
            .setView(box)
            .setCancelable(!force)
            .setPositiveButton(R.string.ok, null)
        if (!force) builder.setNegativeButton(R.string.cancel, null)
        val dialog = builder.create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val n = input.text.toString().trim().replace(" ", "_")
                if (!Regex("[A-Za-z0-9_]{3,24}").matches(n)) {
                    toast(R.string.nick_invalid)
                } else {
                    player = n
                    prefs.edit().putString("player", n).apply()
                    refreshPlayer()
                    fetchProfile()
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    // ------------------------------------------------------------ remote config / news / profile
    private fun loadRemote(showToast: Boolean) {
        val url = (prefs.getString("cfg_url", "") ?: "").ifBlank { cfg.remoteConfigUrl }
        if (url.isBlank()) {
            loadNews()
            return
        }
        Thread {
            try {
                val text = Net.getText(url)
                val parsed = ConfigLoader.parse(text, ConfigLoader.fromAssets(this))
                prefs.edit().putString("remote_cache", text).apply()
                runOnUiThread {
                    cfg = parsed
                    buildServers()
                    updateHeaderActions()
                    refreshStatuses()
                    if (showToast) toast(R.string.msg_cfg_ok)
                    loadNews()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (showToast) toast(R.string.msg_cfg_fail)
                    loadNews()
                }
            }
        }.start()
    }

    private fun loadNews() {
        val url = cfg.newsUrl
        if (url.isBlank()) {
            newsList = cfg.news
            return
        }
        Thread {
            try {
                val items = ConfigLoader.parseNews(JSONArray(Net.getText(url)))
                runOnUiThread { newsList = items }
            } catch (e: Exception) {
                runOnUiThread { newsList = cfg.news }
            }
        }.start()
    }

    private fun fetchProfile() {
        val base = cfg.profileApiUrl
        if (base.isBlank() || player.isBlank()) return
        val url = base + (if (base.contains("?")) "&" else "?") + "nick=" + Net.enc(player)
        Thread {
            try {
                val v = JSONObject(Net.getText(url)).optString("balance", "")
                if (v.isNotBlank()) {
                    runOnUiThread {
                        balance = v
                        balanceViews.forEach { it.text = v }
                    }
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun showNews() {
        val text = if (newsList.isEmpty()) {
            getString(R.string.news_empty)
        } else {
            newsList.joinToString("\n\n") { n ->
                listOf(n.title, n.text, n.date).filter { it.isNotBlank() }.joinToString("\n")
            }
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.news_title)
            .setMessage(text)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    // ------------------------------------------------------------ live status
    private fun refreshStatuses() {
        cfg.servers.forEach { s ->
            Thread {
                val st = StatusRepo.fetch(s)
                runOnUiThread {
                    statuses[s.name] = st
                    holders[s.name]?.let { updateCard(it) }
                    updateTotal()
                }
            }.start()
        }
    }

    private fun updateTotal() {
        val known = statuses.values.filterNotNull().filter { it.online && it.players != null }
        findViewById<TextView>(R.id.tvOnline).text =
            if (known.isEmpty()) "●  —" else "●  " + fmt(known.sumOf { it.players ?: 0 })
    }

    private fun fmt(n: Int): String = n.toString().reversed().chunked(3).joinToString(" ").reversed()

    // ------------------------------------------------------------ server cards
    private fun buildServers() {
        val grid = findViewById<GridLayout>(R.id.serverGrid)
        grid.removeAllViews()
        holders.clear()
        cfg.servers.forEach { s ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = GradientDrawable().apply {
                    cornerRadius = dp(6).toFloat()
                    setColor(C_CARD)
                    setStroke(dp(if (s.color != null) 2 else 1), s.color ?: C_STROKE)
                }
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)
                ).apply { width = 0; setMargins(dp(6), dp(6), dp(6), dp(6)) }
            }

            val count = tv("…", 12f, C_DIM)
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(tv("#", 13f, C_DIM))
            top.addView(tv(" ${s.first}", 15f, Color.WHITE, true))
            if (s.second.isNotBlank()) {
                top.addView(chip(s.second), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
            }
            if (s.x2) top.addView(tv("  x2", 12f, C_YELLOW, true))
            top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            top.addView(count)
            card.addView(top)

            val addr = tv(if (s.ip.isBlank()) getString(R.string.ip_not_set) else "${s.ip}:${s.port}", 11f, C_DIM)
            addr.setPadding(0, dp(6), 0, 0)
            card.addView(addr)

            val progressRow = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                setPadding(0, dp(8), 0, 0)
            }
            val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progressTintList = ColorStateList.valueOf(C_YELLOW)
            }
            val pct = tv("", 11f, C_DIM)
            progressRow.addView(progress, LinearLayout.LayoutParams(-1, dp(6)))
            progressRow.addView(pct)
            card.addView(progressRow)

            val button = tv("", 13f, C_BTN_TEXT, true).apply { gravity = Gravity.CENTER }
            button.setOnClickListener { onCardAction(s) }
            card.addView(button, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(10) })

            val h = CardHolder(s, count, progressRow, progress, pct, button)
            holders[s.name] = h
            grid.addView(card)
            updateCard(h)
        }
    }

    private fun updateCard(h: CardHolder) {
        val s = h.cfg
        val st = statuses[s.name]
        val label: String
        val color: Int
        if (s.ip.isBlank() && s.statusUrl.isBlank()) {
            label = "—"; color = C_DIM
        } else if (!statuses.containsKey(s.name)) {
            label = "…"; color = C_DIM
        } else if (st == null) {
            label = getString(R.string.st_unknown); color = C_DIM
        } else if (!st.online) {
            label = "●  " + getString(R.string.st_offline); color = C_RED
        } else if (st.players != null && st.max != null) {
            label = "●  ${fmt(st.players)}/${st.max}"; color = C_GREEN
        } else {
            label = "●  " + getString(R.string.st_online); color = C_GREEN
        }
        h.count.text = label
        h.count.setTextColor(color)

        val busy = running.containsKey(s.name)
        val text: String
        val purple: Boolean
        if (busy) {
            text = getString(R.string.btn_cancel); purple = true
        } else {
            purple = false
            text = when (stateOf(s)) {
                St.DOWNLOAD -> getString(R.string.btn_download)
                St.UPDATE -> getString(R.string.btn_update)
                St.INSTALL -> getString(R.string.btn_install)
                St.PLAY -> getString(R.string.btn_play)
                St.NOCONFIG -> getString(R.string.btn_play)
            }
        }
        h.button.text = text
        h.button.background = pill(if (purple) C_PURPLE else C_YELLOW)
        h.button.alpha = if (!busy && stateOf(s) == St.NOCONFIG) 0.45f else 1f
    }

    private fun stateOf(s: ServerCfg): St {
        val installed = s.gamePackage.isNotBlank() && isInstalled(s.gamePackage)
        if (s.downloadUrl.isBlank()) return if (installed) St.PLAY else St.NOCONFIG
        val saved = prefs.getString("ver_${s.name}", null)
        val file = GameManager.localFile(this, s)
        return when {
            saved == null -> if (installed) St.PLAY else St.DOWNLOAD
            saved != s.version -> St.UPDATE
            GameManager.isApk(s) && !installed -> if (file.exists()) St.INSTALL else St.DOWNLOAD
            else -> St.PLAY
        }
    }

    private fun onCardAction(s: ServerCfg) {
        val cancel = running[s.name]
        if (cancel != null) {
            cancel.set(true)
            return
        }
        when (stateOf(s)) {
            St.DOWNLOAD, St.UPDATE -> startDownload(s)
            St.INSTALL -> installApk(s)
            St.PLAY -> launchGame(s)
            St.NOCONFIG -> toast(R.string.msg_cfg_missing)
        }
    }

    // ------------------------------------------------------------ download / install / launch
    private fun startDownload(s: ServerCfg) {
        if (prefs.getBoolean("wifi_only", true) && !onWifi()) {
            toast(R.string.msg_wifi)
            return
        }
        val flag = AtomicBoolean(false)
        running[s.name] = flag
        holders[s.name]?.let {
            it.progressRow.visibility = View.VISIBLE
            it.setProgress(0, -1)
            updateCard(it)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            try {
                val dest = GameManager.localFile(this, s)
                Downloader.download(s.downloadUrl, dest, s.sha256, flag) { done, total ->
                    runOnUiThread { holders[s.name]?.setProgress(done, total) }
                }
                if (dest.name.endsWith(".zip", ignoreCase = true)) {
                    GameManager.unzip(dest, GameManager.dataDir(this, s))
                }
                prefs.edit().putString("ver_${s.name}", s.version).apply()
                runOnUiThread { finishDownload(s, 0, "") }
            } catch (e: DownloadCancelled) {
                runOnUiThread { finishDownload(s, 1, "") }
            } catch (e: Exception) {
                runOnUiThread { finishDownload(s, 2, e.message ?: "error") }
            }
        }.start()
    }

    // result: 0 = ok, 1 = paused, 2 = failed
    private fun finishDownload(s: ServerCfg, result: Int, msg: String) {
        running.remove(s.name)
        if (running.isEmpty()) window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        holders[s.name]?.let {
            it.progressRow.visibility = View.GONE
            updateCard(it)
        }
        when (result) {
            0 -> {
                toast(R.string.msg_dl_done)
                postNotification(getString(R.string.msg_dl_done))
                if (GameManager.isApk(s) && stateOf(s) == St.INSTALL) installApk(s)
            }
            1 -> toast(R.string.msg_paused)
            else -> {
                toast(R.string.msg_dl_fail, msg)
                postNotification(getString(R.string.msg_dl_fail, msg))
            }
        }
    }

    private fun installApk(s: ServerCfg) {
        val f = GameManager.localFile(this, s)
        if (!f.exists()) {
            toast(R.string.msg_install_missing)
            return
        }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            toast(R.string.msg_allow_install)
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    // Game ko nickname, server ip/port, graphics aur language intent extras me milte hain.
    private fun launchGame(s: ServerCfg) {
        if (s.gamePackage.isBlank()) {
            toast(R.string.msg_pkg_missing)
            return
        }
        val i = packageManager.getLaunchIntentForPackage(s.gamePackage)
        if (i == null) {
            toast(R.string.msg_game_missing)
            return
        }
        if (player.isBlank()) {
            askName(true)
            return
        }
        i.putExtra("nickname", player)
        i.putExtra("server_name", s.name)
        i.putExtra("server_ip", s.ip)
        i.putExtra("server_port", s.port)
        i.putExtra("graphics_quality", prefs.getString("graphics", "medium"))
        i.putExtra("language", resources.configuration.locales[0].toLanguageTag())
        i.putExtra("data_dir", GameManager.dataDir(this, s).absolutePath)
        startActivity(i)
    }

    private fun postNotification(text: String) {
        if (!prefs.getBoolean("notif", true)) return
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = NotificationManagerCompat.from(this)
        nm.createNotificationChannel(
            NotificationChannelCompat.Builder("downloads", NotificationManagerCompat.IMPORTANCE_DEFAULT)
                .setName("Downloads").build()
        )
        val n = NotificationCompat.Builder(this, "downloads")
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        nm.notify(1001, n)
    }

    // ------------------------------------------------------------ settings screen
    private fun buildSettings() {
        val list = findViewById<LinearLayout>(R.id.settingsList)
        list.removeAllViews()
        list.addView(row(getString(R.string.set_graphics), qualityLabel()) { pickGraphics() })
        list.addView(switchRow(getString(R.string.set_wifi), prefs.getBoolean("wifi_only", true)) {
            prefs.edit().putBoolean("wifi_only", it).apply()
        })
        list.addView(row(getString(R.string.set_clear), null) { clearFiles() })
        list.addView(row(getString(R.string.set_lang), langLabel()) { pickLanguage() })
        list.addView(switchRow(getString(R.string.set_notif), prefs.getBoolean("notif", true)) { on ->
            prefs.edit().putBoolean("notif", on).apply()
            if (on && Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        })
        list.addView(row(getString(R.string.set_cfg), null) { editConfigLink() })
        list.addView(row(getString(R.string.set_support), null) { openUrl(cfg.supportUrl) })
        list.addView(row(getString(R.string.set_version), versionName(), null))
    }

    private fun qualityLabel(): String = when (prefs.getString("graphics", "medium")) {
        "low" -> getString(R.string.q_low)
        "high" -> getString(R.string.q_high)
        else -> getString(R.string.q_med)
    }

    private fun pickGraphics() {
        val items = arrayOf(getString(R.string.q_low), getString(R.string.q_med), getString(R.string.q_high))
        val keys = arrayOf("low", "medium", "high")
        val cur = keys.indexOf(prefs.getString("graphics", "medium")).let { if (it < 0) 1 else it }
        AlertDialog.Builder(this)
            .setTitle(R.string.set_graphics)
            .setSingleChoiceItems(items, cur) { d, which ->
                prefs.edit().putString("graphics", keys[which]).apply()
                d.dismiss()
                buildSettings()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun langTag(): String =
        AppCompatDelegate.getApplicationLocales().toLanguageTags().substringBefore('-')

    private fun langLabel(): String = when (langTag()) {
        "en" -> "English"
        "hi" -> "हिन्दी"
        else -> getString(R.string.lang_system)
    }

    private fun pickLanguage() {
        val tags = arrayOf("", "en", "hi")
        val names = arrayOf(getString(R.string.lang_system), "English", "हिन्दी")
        val cur = tags.indexOf(langTag()).let { if (it < 0) 0 else it }
        AlertDialog.Builder(this)
            .setTitle(R.string.set_lang)
            .setSingleChoiceItems(names, cur) { d, which ->
                d.dismiss()
                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tags[which]))
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun clearFiles() {
        running.values.forEach { it.set(true) }
        GameManager.clearAll(this)
        val e = prefs.edit()
        cfg.servers.forEach { e.remove("ver_${it.name}") }
        e.apply()
        holders.values.forEach { updateCard(it) }
        toast(R.string.msg_cleared)
    }

    private fun editConfigLink() {
        val input = EditText(this).apply {
            hint = "https://www.dropbox.com/..."
            setText(prefs.getString("cfg_url", ""))
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, FrameLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.set_cfg)
            .setMessage(R.string.cfg_msg)
            .setView(box)
            .setPositiveButton(R.string.save) { _, _ ->
                prefs.edit().putString("cfg_url", input.text.toString().trim()).apply()
                loadRemote(true)
            }
            .setNeutralButton(R.string.reset) { _, _ ->
                prefs.edit().remove("cfg_url").remove("remote_cache").apply()
                cfg = ConfigLoader.fromAssets(this)
                buildServers()
                updateHeaderActions()
                refreshStatuses()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun versionName(): String = try {
        "v" + (packageManager.getPackageInfo(packageName, 0).versionName ?: "")
    } catch (e: Exception) {
        ""
    }

    private fun row(title: String, value: String?, onClick: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = cardBg()
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) }
            if (onClick != null) setOnClickListener { onClick() }
        }
        r.addView(tv(title, 14f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        if (value != null) r.addView(tv(value, 13f, C_YELLOW))
        return r
    }

    private fun switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = cardBg()
            setPadding(dp(16), dp(10), dp(16), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) }
        }
        r.addView(tv(title, 14f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(SwitchCompat(this).apply {
            isChecked = checked
            setOnCheckedChangeListener { _, v -> onChange(v) }
        })
        return r
    }

    // ------------------------------------------------------------ navigation
    private fun show(id: Int, push: Boolean = true) {
        val target = screens.getValue(id)
        screens.values.forEach { if (it !== target) it.visibility = View.GONE }
        target.alpha = 0f
        target.visibility = View.VISIBLE
        target.animate().alpha(1f).setDuration(250).start()
        if (push) stack.addLast(id)
    }

    private fun goBack() {
        if (stack.isEmpty()) return
        if (stack.size > 1) {
            stack.removeLast()
            show(stack.last(), push = false)
        } else finish()
    }

    // ------------------------------------------------------------ helpers
    private fun openUrl(url: String) {
        if (url.isBlank()) {
            toast(R.string.msg_no_url)
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            toast(R.string.msg_no_app)
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    private fun onWifi(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    private fun cardBg() = GradientDrawable().apply {
        setColor(C_CARD)
        setStroke(dp(1), C_STROKE)
        cornerRadius = dp(6).toFloat()
    }

    private fun pill(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(3).toFloat()
    }

    private fun chip(t: String): TextView = tv(t, 10f, Color.WHITE).apply {
        background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), C_DIM)
            cornerRadius = dp(3).toFloat()
        }
        setPadding(dp(6), dp(1), dp(6), dp(1))
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(@StringRes id: Int, vararg args: Any) =
        Toast.makeText(this, getString(id, *args), Toast.LENGTH_SHORT).show()
}
