package com.voidxen.launcher

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Account login/register against YOUR server (authApiUrl).
 * POST JSON {"action":"login"|"register","username":"..","password":".."}
 * Response JSON {"ok":true,"token":"..","nickname":"..","balance":"123"} or {"ok":false,"error":".."}
 */
object Auth {
    data class Result(val ok: Boolean, val token: String, val nickname: String, val balance: String, val error: String)

    fun request(url: String, action: String, user: String, pass: String): Result {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("User-Agent", "VoidXenLauncher/1.0")
            val body = JSONObject().put("action", action).put("username", user).put("password", pass).toString()
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
            val o = try {
                JSONObject(text)
            } catch (e: Exception) {
                return Result(false, "", "", "", "Invalid server response (HTTP $code)")
            }
            return Result(
                o.optBoolean("ok", false),
                o.optString("token", ""),
                o.optString("nickname", user),
                o.optString("balance", ""),
                o.optString("error", "")
            )
        } finally {
            c.disconnect()
        }
    }
}
